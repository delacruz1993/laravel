<html>
<head>
	<title> Warriors </title>
	<link rel="icon" href="w.png" type="image">
	<link href="style.css" type="text/css" rel="stylesheet">

	
</head>
<body>
	
	<div class="top">
		<div>
		</div>
	</div>

	<div class="logo">
		<div>
			<table>
				<tr>
					<img src="w.png" width="120" class="left">
				
					<br>
					<br>
					<h1> Warriors</h1>
					<td>
					</td>
				<br>
				</tr>
			</table>
							<a href="home.html">HOME</a> 
							<a href="about.html">ABOUT US</a>  
							<a href="contact.html">CONTACT</a>
							<a href="login.html">LOG IN</a> 
							<a href="register.html">REGISTER</a>
		</div>
	</div>
		
	
		<div id="container">
		<div class="middle">
	    <img src="warriors.png" width="100%" height="200"/>

			<div style="float:right; margin-top:-137px;">
				<div style="margin-top:20px;">
			</div>
			</div>
	</div>	
    <div class="background">
			<center>

				<div>
				
				    <br>
				    <br>
				    <br>
				    <br>
					<h2>Welcome</h2>
					<br>
					<h3>We are the group Warriors and together we could be unstoppable.</h3>
					<br>
					<br>
                    <br>
                    <br>
                    <br>
				</div>
			</center>
			<hr>
</div>
</div>
    <br>
			
    <footer>	
	<div class="bottom">
	<div>
		<center><p>We are Warriors <br> Urdaneta City University</p></center>
	</div>
	</div>
	</footer>
	</body>
	</html>