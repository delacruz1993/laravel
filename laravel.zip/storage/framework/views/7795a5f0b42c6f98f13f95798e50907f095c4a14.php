<!DOCTYPE html>
<html>
<head>
    <title>welcome</title>
</head>
<style type="text/css">
    *{
        background: red;
    }
</style>
<body>
    <h1>welcome to my page</h1>

</body>
</html><?php /**PATH C:\Program Files\Git\example-app\resources\views/welcome.blade.php ENDPATH**/ ?>